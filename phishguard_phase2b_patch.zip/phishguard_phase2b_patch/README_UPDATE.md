Replace the current-status block with:

> **Current status:** Phase 2B — character-level TF-IDF and logistic-regression model
> selection on the domain-held-out validation split. The locked test set remains untouched.

Add under the project commands:

```powershell
uv run python -m phishguard.training.tfidf_logistic
```

For the optional full 18-configuration search:

```powershell
uv run python -m phishguard.training.tfidf_logistic --full-grid
```
